local filteringEnabled = true -- Default is ON
local hasDisplayedState = false -- To track if the state notification has been displayed

local function ToggleFiltering(enable)
    filteringEnabled = enable
    if enable then
        print("Hardcore messages filtering is ON. All Hardcore messages will be hidden.")
    else
        print("Hardcore messages filtering is OFF. All Hardcore messages will be visible.")
    end
end

local function DisplayFilteringState()
    if not hasDisplayedState then
        if filteringEnabled then
            print("Hardcore messages filtering is currently ON.")
        else
            print("Hardcore messages filtering is currently OFF.")
        end
        hasDisplayedState = true
    end
end

HCFilter_ChatFrame_OnEvent = ChatFrame_OnEvent

function ChatFrame_OnEvent(event)
    if event == "PLAYER_LOGIN" or event == "PLAYER_ENTERING_WORLD" then
        if not hasDisplayedState then
            DisplayFilteringState()
            print("Type /hcfilter for more.") -- Display "lol" when logging in or reloading the UI
        end
    end

    if filteringEnabled and event == "CHAT_MSG_SYSTEM" then
        local _, _, hardcore = string.find(arg1, "(Hardcore)")
        if hardcore then
            return true -- Hide the message
        end
    end

    return HCFilter_ChatFrame_OnEvent(event)
end

SLASH_HCFILTER1 = "/hcfilter"
SlashCmdList["HCFILTER"] = function(msg)
    local command = string.lower(msg)

    if command == "on" or command == "enable" then
        -- Enable filtering of system messages containing "hardcore"
        if not filteringEnabled then
            ToggleFiltering(true)
            hasDisplayedState = false -- Reset state notification flag
        else
            print("Hardcore messages filtering is already ON. It's okay, I've got rid of it all for you.")
        end
    elseif command == "off" or command == "disable" then
        -- Disable filtering
        if filteringEnabled then
            ToggleFiltering(false)
            hasDisplayedState = false -- Reset state notification flag
        else
            print("Hardcore messages filtering is already OFF, my dude!")
        end
    elseif command == "info" then
        print("This tiny addon is made by Mint. Whisper Hydromint in game if you have any questions! An update may be available where you can enable/disable specific hardcore messages.")
    else
        -- Display the current state of filtering
        DisplayFilteringState()

        -- Display a list of commands
        print("Usage: /hcfilter [on | off | info]")
        print("   on / enable : Enable filtering of Hardcore messages. Hate the spam? Wanna turn it off? Try this command right here!")
        print("   off / disable : Disable filtering of Hardcore messages. This command right here will clog up your chat.")
        print("   info : More info.")
    end
end
